import com.google.firebase.auth.FirebaseAuth;

public class FirebaseServices
{
    private static FirebaseServices instance;

    // properties
    private FirebaseAuth auth;

    public FirebaseServices() {
        this.auth = FirebaseAuth.getInstance();
    }

    public FirebaseAuth getAuth() {
        return auth;
    }

    public static FirebaseServices getInstance()
    {
        if ( instance== null) {
            instance = new FirebaseServices();
        }
        return instance;
    }
}
